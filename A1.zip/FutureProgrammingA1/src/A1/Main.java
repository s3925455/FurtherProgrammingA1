package A1;

/**
 * Amit Munjal
 * s3925455
 * A1- Wk5
 * The Main class is the entry point of the sample console program.
 * 
 */
public class Main {
    public static void main(String[] args) {
//        VenueMatcher venueMatcher = new VenueMatcher();
        VenueMatcher.run();
    }
}

