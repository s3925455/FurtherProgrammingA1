/**
 * 
 */
package A1.copy2;

/**
 * @author amitmunjal
 *
 */

//Custom exception class
public class CustomException extends Exception {

	private static final long serialVersionUID = 1L;

	public CustomException(String message) {
     super(message);
 }
}
